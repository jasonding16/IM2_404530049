
public class EasterTester 
{

	public static void main(String[] args) 
	{
		Easter easter = new Easter();
		System.out.println("In 2001�A ");
		System.out.println(easter.caculateEaster(2001));
		System.out.println("In 2012�A ");
		System.out.println(easter.caculateEaster(2012));

	}

}
